
+++++++++++++++++++++++++++++++++++
Basic control rundown
+++++++++++++++++++++++++++++++++++

F1    Console toggle.  Not many commands implemented, as this is on the todo list
      to integrate lua into this console
      
WASD  Standard keyboard FPS movement
Shift Run

R     Cycle through render modes (solid, wireframe, pointcloud)

Esc   Exit


+++++++++++++++++++++++++++++++++++
Known bugs
+++++++++++++++++++++++++++++++++++

- Sometimes a terrain is left in the queue for a long time before it loads


+++++++++++++++++++++++++++++++++++
FAQ
+++++++++++++++++++++++++++++++++++

Q. How are you generating the terrain?
A. I'm using Perlin noise.  As a seed, I'm using the string:
   "This is a ridiculously long string" - once I've added a menu system, the end
   user will be able to specify a string to use as a seed.  The string seed is then
   transformed into an integer using a Java-like string hash function.
   
Q. Will the terrain system be compatible with Minecraft?
A. Nope.

Q. What other features are you planning on implementing before a primary release?
A. You can check out the github project pages here:
   http://mrozbarry.github.com/UndeadLand/ , and specifically the "Roadmap" page.
   I'll be updating this page regularly so you know how close I am to an initial
   release.
   
Q. Do I have to buy a copy of undead land?
A. For the time being, no, it is completely free.  You are free to donate to help me
   out.  At some point when the game is much more polished, I may make a commercial
   version.
